D2 RENDER PACKAGE — 3BHK RESIDENCE, VASANT ESTELLA, PUNE
Design intent, for approval — NOT for construction. All dims mm. July 2026.
Ref: Layout Drg. 2906 / Furniture Working Dwg AR/02 (Archiethos, 09/07/2026)

CONTENTS
  D2-drawing-package.html ....... full interactive drawing set (open in any browser;
                                  all 82 drawings, printable, light/dark)
  sheets/D2-00-cover.png ........ cover with project data + sheet index
  sheets/rooms/ ................. 10 room sheets @2x PNG — each with dimensioned
                                  furniture plan + 2 dimensioned elevations + 3D isometric
  sheets/units/ ................. 14 unit sheets @2x PNG — each with dimensioned
                                  front elevation + side section + 3D isometric
  3d-renders/rooms/ ............. 10 standalone 3D isometric renders, one per room
  3d-renders/units/ ............. 14 standalone 3D isometric renders, one per unit

NOTES
  Metric governs (base layout imperial sub-dims carry ~1.55x conversion error — flagged).
  Verify all dimensions by laser measurement before factory production.
  Items marked * fall short of target clearances pending site verification
  (BR2 door-to-slider 870 vs 900; dry balcony passage 475 vs 550).
